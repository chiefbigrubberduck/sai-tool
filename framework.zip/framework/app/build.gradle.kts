plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.chiefbigrubberduck.sai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.chiefbigrubberduck.sai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        buildConfigField "String", "VERSION", "\"${versionName}\""
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                          "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    // Core Android
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")

    // Material Design 3 (rounded buttons, elevation, etc.)
    implementation("com.google.android.material:material:1.11.0")

    // Layout containers
    implementation("androidx.coordinatorlayout:coordinatorlayout:1.2.0")

    // Lifecycle (good practice)
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
}

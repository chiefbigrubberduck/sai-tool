package com.chiefbigrubberduck.sai

/**
 * CENTRAL CONFIGURATION
 *
 * Shell script replaces these values before building:
 * - TARGET_PACKAGE  (line 12)
 * - DISPLAY_NAME    (line 16)
 * - SPLIT_APK_NAMES (lines 22+, auto-detected from folder)
 */
object Config {

    // =========================================================================
    // REWRITE BY BUILD SCRIPT — TARGET APP PACKAGE ID
    // =========================================================================
    const val TARGET_PACKAGE = "com.example.targetapp"

    // =========================================================================
    // REWRITE BY BUILD SCRIPT — HUMAN READABLE NAME (for UI + launcher)
    // =========================================================================
    const val DISPLAY_NAME = "TargetApp"

    // =========================================================================
    // REWRITE BY BUILD SCRIPT — SPLIT APK FILES IN assets/ (AUTO-DETECTED)
    // =========================================================================
    val SPLIT_APK_NAMES = arrayOf(
        "base.apk",
        "config.arm64_v8a.apk",
        "config.xxhdpi.apk"
    )

    // =========================================================================
    // STATIC VALUES (never change between builds)
    // =========================================================================
    const val VERSION_CODE = 1
    const val VERSION_NAME = "1.0.0"
    const val AUTHOR = "chiefbigrubberduck"
    const val YEAR = "2026"

    // Derivatives
    val SPLIT_LIST: List<String> get() = SPLIT_APK_NAMES.toList()
}

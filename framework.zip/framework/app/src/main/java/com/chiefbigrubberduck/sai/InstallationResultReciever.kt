package package com.chiefbigrubberduck.sai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast

class InstallationResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)
        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Unknown"

        when (status) {
            PackageInstaller.STATUS_SUCCESS -> {
                Toast.makeText(context, "✅ Installation Successful!", Toast.LENGTH_LONG).show()
            }
            PackageInstaller.STATUS_FAILURE -> {
                Toast.makeText(context, "❌ Install Failed: $msg", Toast.LENGTH_LONG).show()
            }
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                Toast.makeText(context, "Confirm installation prompt", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(context, "Status: $status - $msg", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

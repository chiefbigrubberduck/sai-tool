package com.chiefbigrubberduck.sai

import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import java.io.File

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // UI BINDINGS
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        val titleText = findViewById<TextView>(R.id.titleText)
        val installBtn = findViewById<MaterialButton>(R.id.installButton)

        // TOOLBAR (empty title)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowHomeEnabled(false)

        // DYNAMIC TEXT
        titleText.text = Config.DISPLAY_NAME
        installBtn.text = "INSTALL"

        updateStatus()

        // BUTTON LISTENER
        installBtn.setOnClickListener {
            if (isTargetInstalled()) {
                Toast.makeText(this, "${Config.DISPLAY_NAME} already installed!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            startInstall()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val titleText = findViewById<TextView>(R.id.titleText)
        val installBtn = findViewById<MaterialButton>(R.id.installButton)

        if (isTargetInstalled()) {
            titleText.text = "${Config.DISPLAY_NAME} ✅"
            installBtn.isEnabled = false
            installBtn.backgroundTintList = getColorStateList(android.R.color.darker_gray)
        } else {
            titleText.text = Config.DISPLAY_NAME
            installBtn.isEnabled = true
            installBtn.backgroundTintList = getColorStateList(R.color.deep_green)
        }
    }

    private fun isTargetInstalled(): Boolean = try {
        packageManager.getPackageInfo(Config.TARGET_PACKAGE, 0)
        true
    } catch (_: Exception) {
        false
    }

    private fun startInstall() {
        val splitFiles = mutableListOf<File>()

        Config.SPLIT_LIST.forEach { name ->
            try {
                copyAssetToCache(name)?.let { splitFiles.add(it) }
            } catch (e: Exception) {
                Toast.makeText(this, "Failed extracting $name: ${e.message}", Toast.LENGTH_SHORT).show()
                return
            }
        }

        if (splitFiles.isEmpty()) {
            Toast.makeText(this, "No split APKs found!", Toast.LENGTH_LONG).show()
            return
        }

        // REQUEST PERMISSION
        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES))
        Toast.makeText(this, "Grant permission, then tap install", Toast.LENGTH_LONG).show()

        beginInstallSession(splitFiles)
    }

    private fun copyAssetToCache(fileName: String): File? {
        val outFile = File(cacheDir, fileName)
        assets.open(fileName).use { input ->
            outFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return outFile
    }

    private fun beginInstallSession(apkFiles: List<File>) {
        try {
            val installer = packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL
            )
            val sessionId = installer.createSession(params)
            val session = installer.openSession(sessionId)

            apkFiles.forEach { apk ->
                session.openWrite(apk.name, 0, apk.length()).use { output ->
                    apk.inputStream().use { input ->
                        input.copyTo(output)
                    }
                    session.fsync(output)
                }
            }

            val intent = Intent(this, InstallationResultReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            session.commit(pendingIntent.intentSender)
            session.close()

            Toast.makeText(this, "Installing ${Config.DISPLAY_NAME}...", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Install failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
